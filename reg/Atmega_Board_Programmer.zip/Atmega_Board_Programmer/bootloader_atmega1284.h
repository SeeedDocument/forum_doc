// File =  optiboot_atmega1284p.hex
// Loader start: 1FC00, length: 1024
// MD5 sum = 71 DD C2 84 64 C4 73 27 D2 33 01 1E FA E1 24 4B 

const byte PROGMEM optiboot_atmega1284p_hex [] = {

}; // end of optiboot_atmega1284p_hex

