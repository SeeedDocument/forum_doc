// File =  stk500boot_v2_mega2560_fixes_watchdog_problem.hex
// Loader start: 3E000, length: 8192
// MD5 sum = 8A F4 7A 29 43 A0 D8 7C DB ED 09 A3 8F 40 24 1E 
// https://github.com/arduino/Arduino-stk500v2-bootloader/blob/master/goodHexFiles/stk500boot_v2_mega2560.hex

const byte PROGMEM atmega2560_v2 [] = {

}; // end of atmega2560_v2

