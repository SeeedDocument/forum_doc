// TestDlg.h : header file
//

#if !defined(AFX_TESTDLG_H__117B3110_5BBE_4F1A_A5E6_ED9556FC9E5F__INCLUDED_)
#define AFX_TESTDLG_H__117B3110_5BBE_4F1A_A5E6_ED9556FC9E5F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CTestDlg dialog

class CTestDlg : public CDialog
{
// Construction
public:
	CTestDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTestDlg)
	enum { IDD = IDD_TEST_DIALOG };
	CComboBox	m_com;
	CString	m_strInfo;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	HANDLE icdev;

	// Generated message map functions
	//{{AFX_MSG(CTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	afx_msg void OnBtat88sc102();
	afx_msg void OnBTConnect();
	afx_msg void OnBtcpu();
	afx_msg void OnBTExit();
	afx_msg void OnBtfcpu();
	afx_msg void OnBtm1();
	afx_msg void OnBtsle();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTDLG_H__117B3110_5BBE_4F1A_A5E6_ED9556FC9E5F__INCLUDED_)
