// TestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Test.h"
#include "TestDlg.h"
#include"tc_32.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestDlg dialog

CTestDlg::CTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestDlg)
	m_strInfo = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestDlg)
	DDX_Control(pDX, IDC_COMBO_COM, m_com);
	DDX_Text(pDX, IDC_EDIT1, m_strInfo);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTestDlg, CDialog)
	//{{AFX_MSG_MAP(CTestDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BTAT88SC102, OnBtat88sc102)
	ON_BN_CLICKED(IDC_BTConnect, OnBTConnect)
	ON_BN_CLICKED(IDC_BTCPU, OnBtcpu)
	ON_BN_CLICKED(IDC_BTExit, OnBTExit)
	ON_BN_CLICKED(IDC_BTFCPU, OnBtfcpu)
	ON_BN_CLICKED(IDC_BTM1, OnBtm1)
	ON_BN_CLICKED(IDC_BTSLE, OnBtsle)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestDlg message handlers

BOOL CTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTestDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTestDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTestDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CTestDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	//CDialog::OnOK();
}

void CTestDlg::OnBtat88sc102() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	CString strOut="";
	__int16 st;
	
	unsigned char nCardType=5;		//������
	unsigned char cPwd[3]={0xff,0xff,0x00};
	unsigned char nDataAddr=0x01,nDataLen=10;		//��ַ�����ݳ���
	unsigned char cReadData[10];
	memset(cReadData,0,10);
	unsigned char cPwd1[7]={0xff,0xff,0xff,0xff,0xff,0xff,0x00}; 
	unsigned char nDataAddr1=0x30,nDataLen1=10;		//��ַ�����ݳ���
	unsigned char cWriteData[10]={0,1,2,3,4,5,6,7,8,9};
	unsigned char writedata[10]={0,1,2,3,4,5,6,7,8,9};
	unsigned char data[20];
	memset(data,0,20);
	unsigned char data1[20];
	memset(data1,0,20);
	
    st=contact_select(icdev,nCardType);
	if(st!=0)
	{
		strOut.Format("%s\r\n","ѡ��ʧ��");
		m_strInfo=m_strInfo+strOut;
		UpdateData(FALSE);
		return;
	}
	else
	{
		strOut.Format("%s\r\n","ѡ���ɹ�");
		m_strInfo=m_strInfo+strOut;
	}
	
	
    st=at88sc102_pwd_check(icdev,cPwd);
	if(st!=0)
	{
		strOut.Format("%s\r\n","at88sc102������У��ʧ��");
		m_strInfo=m_strInfo+strOut;
		UpdateData(FALSE);
		return;
	}
	else
	{
		strOut.Format("%s\r\n","at88sc102������У��ɹ�");
		m_strInfo=m_strInfo+strOut;
	}
	
	st=at88sc102_ua1_readdata(icdev,nDataAddr,nDataLen,cReadData);
	if(st!=0)
	{
		strOut.Format("%s\r\n","at88sc102����ȡ�û���1����ʧ��");
		m_strInfo=m_strInfo+strOut;
		UpdateData(FALSE);
		return;
	}
	else
	{
		hex_asc(cReadData,data,nDataLen);
		strOut.Format("%s\r\n%s\r\n","at88sc102����ȡ�û���1���ݳɹ�",data);
		m_strInfo=m_strInfo+strOut;
	}
	
    st=at88sc102_ua1_epwd_check(icdev,cPwd1);
	if(st!=0)
	{
		strOut.Format("%s\r\n","at88sc102�û���1��������У��ʧ��");
		m_strInfo=m_strInfo+strOut;
		UpdateData(FALSE);
		return;
	}
	else
	{
		strOut.Format("%s\r\n","at88sc102�û���1��������У��ɹ�");
		m_strInfo=m_strInfo+strOut;
	}
	
	st=at88sc102_Anafuse(icdev);
	if(st!=0)
	{
		strOut.Format("%s\r\n","at88sc102��ģ���۶�ʧ��");
		m_strInfo=m_strInfo+strOut;
		UpdateData(FALSE);
		return;
	}
	else
	{
		strOut.Format("%s\r\n","at88sc102��ģ���۶ϳɹ�");
		m_strInfo=m_strInfo+strOut;
	}

	st=at88sc102_ua1_clrdata(icdev);
	if(st!=0)
	{
		strOut.Format("%s\r\n","at88sc102�������û���1����ʧ��");
		m_strInfo=m_strInfo+strOut;
		UpdateData(FALSE);
		return;
	}
	else
	{
		strOut.Format("%s\r\n","at88sc102�������û���1���ݳɹ�");
		m_strInfo=m_strInfo+strOut;
	}
	
    st=at88sc102_ua1_modifydata(icdev,nDataAddr1,nDataLen1,writedata);
	if(st!=0)
	{
		strOut.Format("%s\r\n","at88sc102���û���1���ݸ���ʧ��");
		m_strInfo=m_strInfo+strOut;
		UpdateData(FALSE);
		return;
	}
	else
	{
		hex_asc(cWriteData,data1,nDataLen1);
		strOut.Format("%s\r\n%s\r\n","at88sc102���û���1���ݸ��ĳɹ�",data1);
		m_strInfo=m_strInfo+strOut;
	}

	st=at88sc102_ua1_readdata(icdev,nDataAddr1,nDataLen1,cReadData);
	if(st!=0)
	{
		strOut.Format("%s\r\n","at88sc102����ȡ�û���1����ʧ��");
		m_strInfo=m_strInfo+strOut;
		UpdateData(FALSE);
		return;
	}
	else
	{
		hex_asc(cReadData,data,nDataLen);
		strOut.Format("%s\r\n%s\r\n","at88sc102����ȡ�û���1���ݳɹ�",data);
		m_strInfo=m_strInfo+strOut;
	}
	UpdateData(FALSE);	
}

void CTestDlg::OnBTConnect() 
{
	// TODO: Add your control notification handler code here
	close_device(icdev);
	UpdateData(TRUE);
	CString strOut="";
	__int16 com;
	icdev=NULL;
	if(icdev!=NULL)
	{
		close_device(icdev);
	}
	com=m_com.GetCurSel();
	icdev=open_device((unsigned char)com,115200);
	if((long)icdev<=0)
	{
		strOut.Format("%s\r\n","����ʧ��");
		m_strInfo=m_strInfo+strOut;
	}
	else
	{
		dev_beep(icdev,2,5,2);
		strOut.Format("%s\r\n","���ӳɹ�");
		m_strInfo=m_strInfo+strOut;
	}
	UpdateData(FALSE);
}

void CTestDlg::OnBtcpu() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	CString strOut="";
	__int16 st;
	unsigned char  RLen;
	unsigned char nCardNO=0;
	unsigned char sRDatah[60];
	memset(sRDatah,0,60);
	unsigned short  RLen1;
	unsigned char cCardNO=0;
	unsigned char RDatah[40];
	memset(RDatah,0,40);
	unsigned char SDatah[6]={0x00,0x84,0x00,0x00,0x08,0};
	unsigned char cardno=0;
	unsigned char data[40];
	memset(data,0,40);

    st=ICC_PowerOn(icdev,nCardNO,sRDatah,&RLen);
	if(st!=0)
	{
		strOut.Format("%s\r\n","CPU����λʧ��");
		m_strInfo=m_strInfo+strOut;
		UpdateData(FALSE);
		return;
	}
	else
	{
		strOut.Format("%s\r\n","CPU����λ�ɹ�");
		m_strInfo=m_strInfo+strOut;
	}
	
    st=ICC_CommandExchange(icdev,cCardNO,SDatah,5,RDatah,&RLen1);
	if(st!=0)
	{
		strOut.Format("%s\r\n","CPU��ȡ�����ʧ��");
		m_strInfo=m_strInfo+strOut;
		UpdateData(FALSE);
		return;
	}
	else
	{
		hex_asc(RDatah,data,RLen1);
		strOut.Format("%s\r\n%s\r\n","CPU��ȡ������ɹ�",data);
		m_strInfo=m_strInfo+strOut;
	}
	
	st=ICC_PowerOff(icdev,cardno);
	if(st!=0)
	{
		strOut.Format("%s\r\n","CPU���µ�ʧ��");
		m_strInfo=m_strInfo+strOut;
		UpdateData(FALSE);
		return;
	}
	else
	{
		strOut.Format("%s\r\n","CPU���µ�ɹ�");
		m_strInfo=m_strInfo+strOut;
	}
	UpdateData(FALSE);
}

void CTestDlg::OnBTExit() 
{
	// TODO: Add your control notification handler code here
	close_device(icdev);
	CTestDlg::OnCancel();	
}

void CTestDlg::OnBtfcpu() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	CString strout;
	unsigned char Snrdata[30],info[30],infolen=0;
	if(0==OpenCard(icdev,1,Snrdata,info,&infolen))						//�򿪷ǽ�CPU��Ƭ���õ���ƬID����λ��Ϣ�������demo�鿴
	{
		char infodata[60];
		strout.Format("%s\r\n","�ǽ�CPU���򿪳ɹ���");
		m_strInfo=m_strInfo+strout;
		hex_asc(info,(unsigned char *)infodata,(unsigned long)infolen);
		strout.Format("��Ƭ��Ϣ��%s\r\n",infodata);
		m_strInfo=m_strInfo+strout;
	}
	else
	{
		strout.Format("%s\r\n","�ǽ�CPU����ʧ�ܣ�");
		m_strInfo=m_strInfo+strout;
	}
	unsigned char cmd[5]={0x00,0x84,0x00,0x00,0x08};
	unsigned char recdata[20];
	unsigned short recdatalen=0;
	if(0==ExchangePro(icdev,cmd,5,recdata,&recdatalen))					//��Ϊ��ǽ�CPU�����ݽ�����Ҳ����APDU����
	{
		strout.Format("%s\r\n","�ǽ�CPU��ȡ������ɹ���");
		m_strInfo=m_strInfo+strout;
		char receive[40];
		hex_asc(recdata,(unsigned char*)receive,recdatalen);
		strout.Format("�������%s\r\n",receive);
		m_strInfo=m_strInfo+strout;
	}
	if(0==CloseCard(icdev))												//ͣ��Ƭ����
	{
		strout.Format("%s\r\n","�ǽ�CPU���رճɹ���");
		m_strInfo=m_strInfo+strout;
	}
	else
	{
		strout.Format("%s\r\n","�ǽ�CPU���ر�ʧ�ܣ�");
		m_strInfo=m_strInfo+strout;
	}
	UpdateData(FALSE);	
}

void CTestDlg::OnBtm1() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	CString strout;
	unsigned char snrno[20];
	if(0==rf_card(icdev,1,snrno))							//�򿪿�Ƭ���ɵõ���ƬID
	{
	char snrno1[40];
	hex_asc(snrno,(unsigned char *)snrno1,4);
	strout.Format("%s\r\n","M1��Ѱ���ɹ���");
	m_strInfo=m_strInfo+strout;
	strout.Format("%s\r\n",snrno1);
	m_strInfo=m_strInfo+strout;
	}
	else
	{
		strout.Format("%s\r\n","M1��Ѱ��ʧ�ܣ�");
		m_strInfo=m_strInfo+strout;
	}
	unsigned char key[6]={0xff,0xff,0xff,0xff,0xff,0xff};	//������12����A����Ϊ6��0xff���˴�Ϊ��������֤
	if(0==rf_authentication_key(icdev,1,0x30,key))			//0x30Ϊ���ַ��Ҳ���ǵ�48�飬��12����0��
	{
		strout.Format("%s\r\n","M1����֤�ɹ���");
		m_strInfo=m_strInfo+strout;
	}
	else
	{
		strout.Format("%s\r\n","M1����֤ʧ�ܣ�");
		m_strInfo=m_strInfo+strout;
	}
	unsigned char readdata[17];
	if(0==rf_read(icdev,0x30,readdata))						//��֤�ɹ������48��
	{
		char read1[33];
		hex_asc(readdata,(unsigned char*)read1,16);
		strout.Format("%s\r\n","M1�������ݳɹ���");
		m_strInfo=m_strInfo+strout;
		strout.Format("%s\r\n",read1);
		m_strInfo=m_strInfo+strout;
	}
	else
	{
		strout.Format("%s\r\n","M1��������ʧ�ܣ�");
		m_strInfo=m_strInfo+strout;
	}
	unsigned char writedata1[17]={0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f};
	if(0==rf_write(icdev,0x30,writedata1))					//��֤�ɹ���д��48��Ϊ:0x00,0x01...0x0f
	{
		strout.Format("%s\r\n","M1��д���ݳɹ���");
		m_strInfo=m_strInfo+strout;
	}
	else
	{
		strout.Format("%s\r\n","M1��д��ʧ�ܣ�");
		m_strInfo=m_strInfo+strout;
	}
	if(0==rf_initval(icdev,0x30,100))						//��Ϊ����Ǯ���ĳ�ʼ��ֵ����
	{
		strout.Format("%s\r\n","M1����ʼ���ɹ���");
		m_strInfo=m_strInfo+strout;
	}
	else
	{
		strout.Format("%s\r\n","M1����ʼ��ʧ�ܣ�");
		m_strInfo=m_strInfo+strout;
	}
	if(0==rf_decrement(icdev,0x30,10))						//��Ϊ����Ǯ���ļ�ֵ����
	{
		strout.Format("%s\r\n","M1����ֵ�ɹ���");
		m_strInfo=m_strInfo+strout;
	}
	else
	{
		strout.Format("%s\r\n","M1����ֵʧ�ܣ�");
		m_strInfo=m_strInfo+strout;
	}
	if(0==rf_increment(icdev,0x30,10))						//��Ϊ����Ǯ������ֵ����
	{
		strout.Format("%s\r\n","M1����ֵ�ɹ���");
		m_strInfo=m_strInfo+strout;
	}
	else
	{
		strout.Format("%s\r\n","M1����ֵʧ�ܣ�");
		m_strInfo=m_strInfo+strout;
	}
	unsigned long value1=0;
	if(0==rf_readval(icdev,0x30,&value1))					//��Ϊ����Ǯ���Ķ�ֵ����
	{
		strout.Format("%s\r\n","M1����ֵ�ɹ���");
		m_strInfo=m_strInfo+strout;
		strout.Format("%ld\r\n",value1);
		m_strInfo=m_strInfo+strout;
	}
	else
	{
		strout.Format("%s\r\n","M1����ֵʧ�ܣ�");
		m_strInfo=m_strInfo+strout;
	}
	UpdateData(FALSE);	
}

void CTestDlg::OnBtsle() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	CString strOut="";
	__int16 st;

	unsigned char nCardType=4;		//������
	unsigned char cPwd[4]={0xff,0xff,0xff,0x00};
	unsigned char nDataAddr=0x01,nDataLen=10;		//��ַ�����ݳ���
	unsigned char cReadData[300];
	memset(cReadData,0,300);
	unsigned char nDataAddr1=0x20,nDataLen1=10;		//��ַ�����ݳ���
	unsigned char cWriteData[10]={0,1,2,3,4,5,6,7,8,9};
	unsigned char data[20];
	memset(data,0,20);

    st=contact_select(icdev,nCardType);
	 
	if(st!=0)
	{
		strOut.Format("%s\r\n","ѡ��ʧ��");
		m_strInfo=m_strInfo+strOut;
		UpdateData(FALSE);
		return;
	}
	else
	{
		strOut.Format("%s\r\n","ѡ���ɹ�");
		m_strInfo=m_strInfo+strOut;
	}
	
    st=sle4442_pwd_check(icdev,cPwd);
	if(st!=0)
	{
		strOut.Format("%s\r\n","sle4442����У��ʧ��");
		m_strInfo=m_strInfo+strOut;
		UpdateData(FALSE);
		return;
	}
	else
	{
		strOut.Format("%s\r\n","sle4442����У��ɹ�");
		m_strInfo=m_strInfo+strOut;
	}
	
    st=sle4442_read(icdev,nDataAddr,nDataLen,cReadData);
	if(st!=0)
	{
		strOut.Format("%s\r\n","sle4442������ʧ��");
		m_strInfo=m_strInfo+strOut;
		UpdateData(FALSE);
		return;
	}
	else
	{
		hex_asc(cReadData,data,10);
		strOut.Format("%s\r\n%s\r\n","sle4442�����ݳɹ�,���ݣ�",data);
		m_strInfo=m_strInfo+strOut;
	}
	
    st=sle4442_write(icdev,nDataAddr1,nDataLen1,cWriteData);
	if(st!=0)
	{
		strOut.Format("%s\r\n","sle4442д����ʧ��");
		m_strInfo=m_strInfo+strOut;
		UpdateData(FALSE);
		return;
	}
	else
	{
		strOut.Format("%s\r\n","sle4442д���ݳɹ�");
		m_strInfo=m_strInfo+strOut;
	}
	UpdateData(FALSE);	
}
